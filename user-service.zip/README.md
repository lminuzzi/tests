# User Service

A simple Spring Boot 3 (Java 21) microservice that exposes CRUD operations for a `User` entity using:
- Spring Web
- Spring Data JPA
- Spring Security (Basic Auth)
- H2 in-memory DB
- Lombok

## Run

```bash
mvn spring-boot:run
```

or

```bash
mvn clean package
java -jar target/user-service-1.0.0.jar
```

### Auth
- Username: `admin`
- Password: `password`

### Endpoints
- `GET /api/users`
- `GET /api/users/{id}`
- `POST /api/users`
- `PUT /api/users/{id}`
- `DELETE /api/users/{id}`

### H2 Console
- `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:testdb`
